##Shell特殊变量：Shell $0, $#, $*, $@, $?, $$和命令行参数
变量名只能包含数字、字母和下划线，因为某些包含其他字符的变量有特殊含义，这样的变量被称为特殊变量。
例如，$ 表示当前Shell进程的ID，即pid，看下面的代码：
	
	$echo $$
	34632
<center>特殊变量列表</center>

|变量|含义|  
|:-|:-|  
|$0|当前脚本的文件名|  
|$n|传递给脚本或函数的参数。n 是一个数字，表示第几个参数。例如，第一个参数是$1，第二个参数是$2|  
|$#|传递给脚本或函数的参数个数|  
|$*|传递给脚本或函数的所有参数|  
|$@|传递给脚本或函数的所有参数。被双引号(" ")包含时，与 $* 稍有不同|  
|$?|上个命令的退出状态，或函数的返回值|  
|$$|当前Shell进程ID。对于 Shell 脚本，就是这些脚本所在的进程ID|  

###命令行参数
运行脚本时传递给脚本的参数称为命令行参数。命令行参数用 $n 表示，例如，$1 表示第一个参数，$2 表示第二个参数，依次类推。
如下脚本：

	#!/bin/bash
	echo "File Name: $0"
	echo "First Parameter : $1"
	echo "First Parameter : $2"
	echo "Quoted Values: $@"
	echo "Quoted Values: $*"
	echo "Total Number of Parameters : $#"
./test.sh Zara Ali运行结果：

	File Name : ./test.sh
	First Parameter : Zara
	Second Parameter : Ali
	Quoted Values: Zara Ali
	Quoted Values: Zara Ali
	Total Number of Parameters : 2
###$* 和 $@ 的区别
$* 和 $@ 都表示传递给函数或脚本的所有参数，不被双引号(" ")包含时，都以"$1" "$2" … "$n" 的形式输出所有参数。  
下面的例子可以清楚的看到 $* 和 $@ 的区别：  

	#!/bin/bash
	echo "\$*=" $*
	echo "\"\$*\"=" "$*"
	echo "\$@=" $@
	echo "\"\$@\"=" "$@"
	echo "print each param from \$*"
	for var in $*
	do
	    echo "$var"
	done
	echo "print each param from \$@"
	for var in $@
	do
	    echo "$var"
	done
	echo "print each param from \"\$*\""
	for var in "$*"
	do
	    echo "$var"
	done
	echo "print each param from \"\$@\""
	for var in "$@"
	do
	    echo "$var"
	done
执行 ./test.sh "a" "b" "c" "d"，看到下面的结果：

	$*=  a b c d
	"$*"= a b c d
	$@=  a b c d
	"$@"= a b c d
	print each param from $*
	a
	b
	c
	d
	print each param from $@
	a
	b
	c
	d
	print each param from "$*"
	a b c d
	print each param from "$@"
	a
	b
	c
	d
###退出状态
$? 可以获取上一个命令的退出状态。所谓退出状态，就是上一个命令执行后的返回结果。  
退出状态是一个数字，一般情况下，大部分命令执行成功会返回 0，失败返回 1，也有一些命令返回其他值，表示不同类型的错误。  

